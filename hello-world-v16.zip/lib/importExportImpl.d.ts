export declare function exportWallet(): Promise<boolean>;
export declare function importWalletFile(): Promise<string | null>;
