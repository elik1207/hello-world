// No-op for native platforms to prevent CSS bundling errors
